/*
 * tcping.c
 *
 * Copyright (c) 2002-2008 Marc Kirchner <mail(at)marc(dash)kirchner(dot)de>
 *
 * tcping is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * tcping is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with ms++. If not, see <http://www.gnu.org/licenses/>.
 *
 * tcping does a nonblocking connect to test if a port is reachable.
 * Its exit codes are:
 *     -1 an error occured
 *     0  port is open
 *     1  port is closed
 *     2  user timeout
 */

#define VERSION 1.3.5

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif
#include <unistd.h>
#include <sys/time.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <netdb.h>

void usage();

int main (int argc, char *argv[]) {

	int sockfd;
	struct sockaddr_in addr;
	struct hostent *host;
	int error = 0;
	int ret;
	socklen_t errlen;
	struct timeval timeout;
	struct timeval startTime;
	struct timeval stopTime;
	struct timeval diffTime;
	fd_set fdrset, fdwset;
	int verbose=0;
	int c;
	char *cptr;
	long timeout_sec=0, timeout_usec=0;
	int port=0;

	double rtt,
	       minRtt   = 1000000.0,
	       maxRtt   = 0.0,
	       totalRtt = 0.0;

	int    successfulPings = 0,
	       failedPings = 0,
	       count,
	       n = 1,
	       exitStatus = 0;

	if (argc < 3)  {
		usage(argv[0]);
	}
	
	while((c = getopt(argc, argv, "qt:u:n:v")) != -1) {
		switch(c) {
			case 'q':
				verbose = 0;
				break;
			case 't':
				cptr = NULL;
				timeout_sec = strtol(optarg, &cptr, 10);
				if (cptr == optarg)
					usage(argv[0]);
				break;
			case 'u':
				cptr = NULL;
				timeout_usec = strtol(optarg, &cptr, 10);
				if (cptr == optarg)
					usage(argv[0]);
				break;
			case 'n':
				n = atoi(optarg);
				if (n <= 0)
				{
					fprintf(stderr, "n must be greater than 0\n");
					exit(1);
				}
				break;
			case 'v':
				verbose = 1;
				break;
			default:
				usage(argv[0]);
				break;
		}
	}
	
    count = n;
    while (count)
    {
    	count--;
	    sockfd = socket (AF_INET, SOCK_STREAM, 0);

	    memset(&addr, 0, sizeof(addr));

	    if ((host = gethostbyname(argv[optind])) == NULL)
	    {
#ifdef HAVE_HSTRERROR
			fprintf(stderr, "error: %s\n", hstrerror(h_errno));
#else
			fprintf(stderr, "error: host not found");
#endif
		    failedPings++;
		    exitStatus++;
		    continue;
	    }
	
	    memcpy(&addr.sin_addr, host->h_addr_list[0], host->h_length);
	    addr.sin_family = host->h_addrtype; /* always AF_INET */
	    if (argv[optind+1])
	    {
    		cptr = NULL;
		    port = strtol(argv[optind+1], &cptr, 10);
		    if (cptr == argv[optind+1])
    			usage(argv[0]);
    	}
	    else
	    {
		    usage(argv[0]);
	    }
	    addr.sin_port = htons(port);

	    fcntl(sockfd, F_SETFL, O_NONBLOCK);
            gettimeofday(&startTime, NULL);

	    if ((ret = connect(sockfd, (struct sockaddr *) &addr, sizeof(addr))) != 0)
	    {
		    if (errno != EINPROGRESS)
		    {
#ifdef HAVE_SOLARIS
			    /* solaris immediately returns ECONNREFUSED on local ports */
			    if (errno == ECONNREFUSED)
			    {
			    	failedPing++;
			    	close(sockfd);
				    fprintf(stdout, "  Connection refused\n");
				    exitStatus = 1;
				    continue;
			    }
			    else
			    {
#endif
			    	close(sockfd);
			    	failedPings++;
					fprintf(stderr, "  Connect failed: %s\n", strerror(errno));
				    exitStatus = 1;
				    continue;
#ifdef HAVE_SOLARIS
			    }
#endif	
		    }

		    FD_ZERO(&fdrset);
		    FD_SET(sockfd, &fdrset);
		    fdwset = fdrset;

		    timeout.tv_sec=timeout_sec + timeout_usec / 1000000;
		    timeout.tv_usec=timeout_usec % 1000000;

		    if ((ret = select(sockfd+1, &fdrset, &fdwset, NULL, timeout.tv_sec+timeout.tv_usec > 0 ? &timeout : NULL)) == 0)
		    {
			    /* timeout */
			    close(sockfd);
			    failedPings++;
				fprintf(stdout, "  Connection timeout\n");
				exitStatus = 1;
			    continue;
		    }

		    gettimeofday(&stopTime, NULL);

		    if (FD_ISSET(sockfd, &fdrset) || FD_ISSET(sockfd, &fdwset))
		    {
    			errlen = sizeof(error);
			    if ((ret=getsockopt(sockfd, SOL_SOCKET, SO_ERROR, &error, &errlen)) != 0)
			    {
    				/* getsockopt error */
				    fprintf(stderr, "error: %s port %s: getsockopt: %s\n", argv[optind], argv[optind+1], strerror(errno));
				    close(sockfd);
				    failedPings++;
				    exitStatus = 1;
				    continue;
			    }
			    if (error != 0)
			    {
					fprintf(stdout, "  %s port %s closed.\n", argv[optind], argv[optind+1]);
				    close(sockfd);
				    failedPings++;
				    exitStatus = 1;
				    continue;
			    }
		    }
		    else
		    {
				fprintf(stderr, "error: select: sockfd not set\n");
 			    close(sockfd);
 			    failedPings++;
 			    exitStatus = 1;
 			    continue;
		    }
	    }
	    /* OK, connection established */
	    close(sockfd);

	    successfulPings++;
	    timersub(&stopTime, &startTime, &diffTime);
        rtt = diffTime.tv_usec/1000.0;
        if (rtt > maxRtt)
        	maxRtt = rtt;
        if (rtt < minRtt)
    	    minRtt = rtt;
        totalRtt += rtt;

        fprintf(stdout, "  Reply from %s:%d  time=%-5.3fms\n", argv[optind], port, rtt);
    } // end while

    fprintf(stdout, "%d packets transmitted, %d packets received\n", n, successfulPings);
    fprintf(stdout, "min = %-5.3f, avg = %-5.3f, max = %-5.3f\n\n", minRtt, totalRtt/successfulPings, maxRtt);

    exit (exitStatus);
}

void usage(char *prog) {
	fprintf(stderr, "error: Usage: %s [-q] [-t timeout_sec] [-u timeout_usec] <host> <port>\n", prog);
		exit(-1);
}
	

